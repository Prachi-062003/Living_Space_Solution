# Hostel-Management-System-
To use this project just follow these steps:

Step 1
Copy the code in Step 1.py file and paste in your main project file(.py) and run the file

Step 2
Now, Delete that code after successfull execution of main project file(.py)

Step 3
Now, Add The main code of Hostel Management System to your project file(.py)

----------------------------------------------------

Use this username and password

Username = Prachi@06
Password = Pass@123


